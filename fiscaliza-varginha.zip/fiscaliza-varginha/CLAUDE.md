# Zela Varginha — Fiscalização Cidadã

Squad de monitoramento automático da Câmara Municipal de Varginha (MG).

## Estrutura do projeto

```
fiscaliza-varginha/
├── squads/fiscaliza-varginha/
│   ├── squad.yaml                    ← Definição dos agentes
│   ├── _investigations/
│   │   ├── fontes_preferenciais.md   ← URLs das fontes oficiais
│   │   └── perfis_vereadores.json    ← Redes sociais dos vereadores
│   ├── output/                       ← Dados gerados pelo squad
│   ├── scripts/
│   │   ├── notify_telegram.js        ← Envio de alertas no Telegram
│   │   ├── test_telegram.js          ← Teste da conexão Telegram
│   │   ├── extract_pdf.js            ← Extração de PDFs do Diário Oficial
│   │   ├── extract_cnpj.js           ← Validação de CNPJs via ReceitaWS
│   │   └── scrape_social.js          ← Scraping de redes sociais
│   ├── dashboard/                    ← Painel visual (abrir no navegador)
│   │   ├── index.html
│   │   ├── style.css
│   │   └── script.js
│   └── .env.example                  ← Template de variáveis de ambiente
├── package.json
├── .mcp.json                         ← Configuração do MCP Playwright
└── CLAUDE.md                         ← Este arquivo
```

## Configuração inicial (fazer apenas uma vez)

```bash
# 1. Instalar dependências
npm install
npm run install:browsers

# 2. Criar arquivo .env
cp squads/fiscaliza-varginha/.env.example squads/fiscaliza-varginha/.env
# Editar .env com token do Telegram

# 3. Testar conexão Telegram
npm run telegram:test

# 4. Preencher perfis dos vereadores
# Editar: squads/fiscaliza-varginha/_investigations/perfis_vereadores.json

# 5. Verificar URLs das fontes
# Editar: squads/fiscaliza-varginha/_investigations/fontes_preferenciais.md
```

## Execução

```bash
# Executar o squad completo (Claude Code)
/opensquad run fiscaliza-varginha

# Abrir dashboard no navegador
npm run dashboard
# → http://localhost:3000

# Enviar notificação Telegram manualmente
npm run telegram:send

# Extrair PDF do Diário Oficial manualmente
npm run extract:pdf https://url-do-pdf.pdf

# Validar CNPJs de um arquivo
npm run extract:cnpj output/dados_camara.json --api

# Scraping de redes sociais
npm run scrape:redes
```

## Agentes do Squad

| Agente | Função | Saída |
|--------|--------|-------|
| verificador_fontes | Testa acesso às URLs | fontes_status.json |
| extrator_camara | Raspa dados da Câmara | dados_camara.json |
| extrator_pdf_diario | Extrai PDFs do Diário Oficial | pdf_diario_raw.json |
| extrator_cnpjs | Valida CNPJs via ReceitaWS | cnpjs_beneficiarios.json |
| analista_recorrencia | Score de risco por beneficiário | analise_recorrencia.json |
| scraper_redes | Posts dos vereadores nas redes | redes_sociais_raw.json |
| analista_redes | Score de transparência + conflitos | analise_redes.json |
| analista_cidadao | Resumo para o cidadão | analise_cidadao.json |
| gerador_relatorio | Relatório final | relatorio_YYYY_MM_DD.md |
| notificador_telegram | Envio de alertas | (Telegram) |

## Agendamento automático

O squad está configurado para rodar toda segunda-feira às 9h (schedule no squad.yaml).
Para que funcione automaticamente, o Claude Code precisa estar em execução.

## Configuração do Telegram

1. Acesse @BotFather no Telegram
2. Envie `/newbot` e siga as instruções
3. Guarde o token gerado
4. Para descobrir seu Chat ID: envie uma mensagem para @userinfobot
5. Preencha `.env` com `TELEGRAM_BOT_TOKEN` e `TELEGRAM_CHAT_ID`
6. Teste: `npm run telegram:test`

## Fontes de dados

- **Câmara:** https://www.camaragua.vote.br
- **Transparência:** https://transparencia.camaragua.vote.br
- **Diário Oficial:** https://www.varginha.mg.gov.br/diario-oficial
- **API CNPJ:** https://www.receitaws.com.br (gratuita, 3 req/min)
