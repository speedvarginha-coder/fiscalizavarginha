# Fontes Oficiais - Câmara de Varginha (URLs verificadas)

## Câmara Municipal de Varginha
- **Site oficial:** https://www.camaragua.vote.br
- **Transparência:** https://transparencia.camaragua.vote.br
- **Sessões plenárias (YouTube):** https://www.youtube.com/@camaravarginha
- **Atividades legislativas:** https://www.camaragua.vote.br/atividades
- **Emendas:** https://transparencia.camaragua.vote.br/emendas
- **Beneficiários:** https://transparencia.camaragua.vote.br/emendas/beneficiarios

## Diário Oficial
- **Prefeitura de Varginha:** https://www.varginha.mg.gov.br/diario-oficial
- **Edições (PDF):** https://www.varginha.mg.gov.br/diario-oficial/edicoes
- **Busca por período:** https://www.varginha.mg.gov.br/diario-oficial/busca

## Contratos e Licitações
- **Licitações:** https://transparencia.varginha.mg.gov.br/licitacoes
- **Contratos:** https://transparencia.varginha.mg.gov.br/contratos

## API de Validação de CNPJ
- **ReceitaWS (gratuita, 3 req/min):** https://www.receitaws.com.br/v1/cnpj/{cnpj}

## Metodologia de Extração
1. Navegar com playwright (sessão persistente)
2. Buscar por elementos: `.emenda-card`, `.sessao-item`, `.diario-link`
3. Fallback: capturar texto bruto da página
4. Validar dados (valores numéricos, datas, CPF/CNPJ)

## Headers para scraping
```
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36
Accept: text/html,application/xhtml+xml
Accept-Language: pt-BR,pt;q=0.9
```

## Autenticação
- Alguns portais exigem login para dados detalhados
- Login manual uma vez via playwright com --headed
- Sessão salva em `_opensquad/_browser_profile/`
