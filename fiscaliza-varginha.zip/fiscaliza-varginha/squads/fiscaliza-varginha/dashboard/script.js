/* =====================================================
   ZELA VARGINHA — Dashboard Script
   ===================================================== */

const fmt = v => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v || 0);
const fmtNum = v => new Intl.NumberFormat('pt-BR').format(v || 0);

/* ---------- Dados de exemplo (usados se o squad ainda não rodou) ---------- */
function dadosExemplo() {
    return {
        data_geracao: new Date().toISOString(),
        total_emendas: 12,
        total_valor: 1247500,
        total_sessoes: 3,
        total_contratos: 4,
        alertas: [
            {
                titulo: "Vereador concentra R$ 380 mil em única ONG",
                descricao: "70% das emendas foram para a Associação Amigos do Bairro (CNPJ: 12.345.678/0001-90)",
                valor: 380000,
                score_risco: 85,
                vereador: "João Silva",
                telefone: "(35) 99999-1234",
                email: "joao.silva@camaravarginha.mg.gov.br",
                como_cobrar: "Solicite notas fiscais e comprovação dos serviços prestados"
            },
            {
                titulo: "Emenda com descrição genérica 'Serviços diversos'",
                descricao: "Emenda nº 045/2025 — Falta transparência no detalhamento",
                valor: 87000,
                score_risco: 60,
                como_cobrar: "Solicite detalhamento via ouvidoria 156"
            }
        ],
        vereadores: [
            { nome: "João Silva", partido: "PL", emendas: 380000, score_transparencia: 35 },
            { nome: "Maria Santos", partido: "PT", emendas: 245000, score_transparencia: 78 },
            { nome: "Carlos Souza", partido: "PSDB", emendas: 180500, score_transparencia: 62 },
            { nome: "Ana Paula", partido: "MDB", emendas: 95000, score_transparencia: 85 }
        ],
        cnpjs: [
            { cnpj: "12.345.678/0001-90", nome: "Associação Amigos do Bairro", total_valor: 380000, ocorrencias: 6, nivel_risco: "ALTO", score_risco: 85 },
            { cnpj: "98.765.432/0001-10", nome: "Hospital Regional Ltda", total_valor: 245000, ocorrencias: 3, nivel_risco: "MÉDIO", score_risco: 55 },
            { cnpj: "11.222.333/0001-44", nome: "Creche Novo Horizonte", total_valor: 95000, ocorrencias: 2, nivel_risco: "BAIXO", score_risco: 20 }
        ],
        diario: [
            { data: "09/05/2025", titulo: "Nomeações: 3 novos cargos comissionados", tipo: "nomeacoes" },
            { data: "08/05/2025", titulo: "Licitação: Pavimentação Bairro Jardim — R$ 2,1M", tipo: "licitacoes" },
            { data: "07/05/2025", titulo: "Contrato: Empresa XYZ vence pregão de material hospitalar", tipo: "contratos" }
        ],
        dica_geral: "Esta semana: 3 pontos críticos identificados. Cobre o vereador João Silva sobre os R$ 380 mil concentrados em uma única ONG."
    };
}

/* ---------- Carregamento de dados ---------- */
async function carregarDados() {
    try {
        const r = await fetch('../output/dados_dashboard.json');
        if (!r.ok) throw new Error('arquivo não encontrado');
        return await r.json();
    } catch (_) {
        console.info('Usando dados de exemplo — execute o squad para dados reais');
        return dadosExemplo();
    }
}

/* ---------- Renderização ---------- */
function renderHeader(dados) {
    document.getElementById('data-atualizacao').textContent =
        dados.data_geracao
            ? new Date(dados.data_geracao).toLocaleString('pt-BR')
            : new Date().toLocaleString('pt-BR');

    document.getElementById('total-emendas').textContent = fmtNum(dados.total_emendas);
    document.getElementById('valor-total').textContent = fmt(dados.total_valor);
    document.getElementById('total-sessoes').textContent = fmtNum(dados.total_sessoes);
    document.getElementById('total-alertas').textContent = fmtNum(dados.alertas?.length);
}

function renderAlertas(alertas) {
    const el = document.getElementById('alertas-lista');
    if (!alertas?.length) { el.innerHTML = '<p>✅ Nenhum alerta crítico nesta semana.</p>'; return; }

    el.innerHTML = alertas.map(a => `
        <div class="alerta-item">
            <h4>⚠️ ${a.titulo}</h4>
            <div class="valor-alerta">${fmt(a.valor)}</div>
            <p>${a.descricao}</p>
            <div class="como-cobrar">
                <strong>📢 Como cobrar:</strong> ${a.como_cobrar || ''}
                ${a.telefone ? `<br>📞 ${a.telefone}` : ''}
                ${a.email ? `<br>📧 ${a.email}` : ''}
            </div>
        </div>
    `).join('');
}

function renderTransparencia(vereadores) {
    const el = document.getElementById('ranking-transparencia');
    if (!vereadores?.length) { el.innerHTML = '<p class="loading">Aguardando dados...</p>'; return; }

    const sorted = [...vereadores].sort((a, b) => (b.score_transparencia || 0) - (a.score_transparencia || 0));
    el.innerHTML = sorted.map(v => {
        const score = v.score_transparencia || 0;
        const nivel = score >= 70 ? 'alto' : score >= 40 ? 'medio' : 'baixo';
        const emoji = score >= 70 ? '✅' : score >= 40 ? '⚠️' : '🔴';
        return `
            <div class="vereador-row">
                <div class="vereador-info">
                    <span class="vereador-nome">${emoji} ${v.nome}</span>
                    <span class="vereador-partido">${v.partido}</span>
                </div>
                <span class="score-badge score-${nivel}">${score}/100</span>
            </div>
        `;
    }).join('');
}

let grafico = null;
function renderGrafico(vereadores) {
    if (!vereadores?.length) return;
    const canvas = document.getElementById('grafico-vereadores');
    if (!canvas) return;

    if (grafico) grafico.destroy();

    const sorted = [...vereadores].sort((a, b) => b.emendas - a.emendas);
    const cores = sorted.map((_, i) => `hsl(${220 + i * 30}, 70%, ${50 + i * 5}%)`);

    grafico = new Chart(canvas, {
        type: 'bar',
        data: {
            labels: sorted.map(v => v.nome),
            datasets: [{
                label: 'Emendas (R$)',
                data: sorted.map(v => v.emendas),
                backgroundColor: cores,
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: {
                y: { ticks: { callback: v => 'R$ ' + fmtNum(v) } }
            }
        }
    });
}

let todosCNPJs = [];
function renderCNPJs(cnpjs) {
    todosCNPJs = cnpjs || [];
    filtrarCNPJs('todos');
}

function filtrarCNPJs(filtro) {
    const el = document.getElementById('tabela-cnpj');
    const lista = filtro === 'todos' ? todosCNPJs : todosCNPJs.filter(c => c.nivel_risco === filtro);

    if (!lista.length) { el.innerHTML = '<p>Nenhum registro encontrado.</p>'; return; }

    const sorted = [...lista].sort((a, b) => (b.score_risco || 0) - (a.score_risco || 0));

    el.innerHTML = `
        <table class="cnpj-table">
            <thead>
                <tr>
                    <th>CNPJ</th>
                    <th>Beneficiário</th>
                    <th>Valor Total</th>
                    <th>Risco</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                ${sorted.map(c => `
                    <tr class="risco-${c.nivel_risco}">
                        <td><code>${c.cnpj}</code></td>
                        <td>${c.nome || '—'}</td>
                        <td>${fmt(c.total_valor)}</td>
                        <td><span class="badge-risco ${c.nivel_risco}">${c.nivel_risco}</span></td>
                        <td><button class="btn-detalhe" onclick="detalharCNPJ('${c.cnpj}','${c.nome}')">🔍</button></td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

function detalharCNPJ(cnpj, nome) {
    alert(`CNPJ: ${cnpj}\nBeneficiário: ${nome || '—'}\n\nConsulte o histórico completo em:\nhttps://www.receitaws.com.br/v1/cnpj/${cnpj.replace(/\D/g, '')}`);
}

function renderDiario(diario) {
    const el = document.getElementById('diario-lista');
    if (!diario?.length) { el.innerHTML = '<p class="loading">Aguardando dados...</p>'; return; }

    el.innerHTML = diario.map(d => `
        <div class="diario-item">
            <span class="diario-data">${d.data}</span>
            <span class="diario-titulo">${d.titulo}</span>
        </div>
    `).join('');
}

/* ---------- Ações ---------- */
function abrirOuvidoria() { alert('Ouvidoria Municipal de Varginha\n📞 156\n🌐 ouvidoria.varginha.mg.gov.br'); }
function abrirTransparencia() { window.open('https://transparencia.camaragua.vote.br', '_blank'); }
function abrirDiario() { window.open('https://www.varginha.mg.gov.br/diario-oficial', '_blank'); }
function compartilhar() {
    if (navigator.share) {
        navigator.share({ title: 'Zela Varginha', text: 'Confira o relatório de fiscalização da Câmara de Varginha!', url: window.location.href });
    } else {
        navigator.clipboard.writeText(window.location.href).then(() => alert('Link copiado para a área de transferência!'));
    }
}

/* ---------- Busca ---------- */
document.getElementById('btn-buscar')?.addEventListener('click', () => {
    const termo = document.getElementById('search-input').value.trim().toLowerCase();
    if (!termo) return;

    const resultCNPJ = todosCNPJs.filter(c =>
        (c.cnpj || '').toLowerCase().includes(termo) ||
        (c.nome || '').toLowerCase().includes(termo)
    );

    if (resultCNPJ.length) {
        document.querySelector('.cnpj-section')?.scrollIntoView({ behavior: 'smooth' });
        filtrarCNPJs('todos');
        const el = document.getElementById('tabela-cnpj');
        if (el) el.innerHTML = `<p>🔍 ${resultCNPJ.length} resultado(s) para "${termo}"</p>` + el.innerHTML;
    } else {
        alert(`Nenhum resultado encontrado para "${termo}"`);
    }
});

document.getElementById('search-input')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') document.getElementById('btn-buscar')?.click();
});

/* ---------- Filtros CNPJ ---------- */
document.querySelectorAll('.filtro-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.filtro-btn').forEach(b => b.classList.remove('ativo'));
        btn.classList.add('ativo');
        filtrarCNPJs(btn.dataset.filtro);
    });
});

/* ---------- Init ---------- */
carregarDados().then(dados => {
    renderHeader(dados);
    renderAlertas(dados.alertas);
    renderTransparencia(dados.vereadores);
    renderGrafico(dados.vereadores);
    renderCNPJs(dados.cnpjs);
    renderDiario(dados.diario);
}).catch(err => {
    console.error('Erro ao carregar dados:', err);
});
