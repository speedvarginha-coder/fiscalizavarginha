/**
 * extract_cnpj.js
 * Extrai e valida CNPJs de documentos, cruzando com a API ReceitaWS
 * 
 * Uso: node extract_cnpj.js [arquivo.json ou arquivo.txt]
 */

require('dotenv').config({ path: '../.env' });
const fs = require('fs');
const path = require('path');

const RECEITAWS_BASE = 'https://www.receitaws.com.br/v1/cnpj';
const DELAY_MS = 22000; // Rate limit: 3 req/min (20s + margem)

class CNPJExtractor {
    constructor() {
        this.cnpjFormatado = /\b\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}\b/g;
        this.cnpjBruto = /\b(\d{14})\b/g;
    }

    extrairDe(text) {
        const encontrados = new Map();

        // Busca CNPJ formatado (XX.XXX.XXX/XXXX-XX)
        for (const match of text.matchAll(new RegExp(this.cnpjFormatado.source, 'g'))) {
            const limpo = match[0].replace(/\D/g, '');
            if (this.validarDigitos(limpo)) {
                encontrados.set(limpo, match[0]);
            }
        }

        // Busca CNPJ bruto (14 dígitos seguidos)
        for (const match of text.matchAll(new RegExp(this.cnpjBruto.source, 'g'))) {
            const limpo = match[1];
            if (!encontrados.has(limpo) && this.validarDigitos(limpo)) {
                const formatado = limpo.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5');
                encontrados.set(limpo, formatado);
            }
        }

        return [...encontrados.entries()].map(([limpo, formatado]) => ({ limpo, formatado }));
    }

    validarDigitos(cnpj) {
        if (cnpj.length !== 14) return false;
        if (/^(\d)\1+$/.test(cnpj)) return false; // todos iguais

        const calc = (arr, pesos) => {
            const soma = arr.reduce((acc, d, i) => acc + d * pesos[i], 0);
            const resto = soma % 11;
            return resto < 2 ? 0 : 11 - resto;
        };

        const digits = cnpj.split('').map(Number);
        const p1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
        const p2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];

        return (
            calc(digits.slice(0, 12), p1) === digits[12] &&
            calc(digits.slice(0, 13), p2) === digits[13]
        );
    }

    async consultarReceitaWS(cnpjLimpo) {
        try {
            console.log(`  🔍 Consultando ReceitaWS: ${cnpjLimpo}`);
            const response = await fetch(`${RECEITAWS_BASE}/${cnpjLimpo}`);
            if (!response.ok) return { erro: `HTTP ${response.status}` };
            const data = await response.json();

            if (data.status === 'ERROR') return { erro: data.message };

            return {
                nome: data.nome,
                fantasia: data.fantasia || '',
                situacao: data.situacao,
                abertura: data.abertura,
                natureza_juridica: data.natureza_juridica,
                capital_social: data.capital_social,
                cnae_principal: data.cnae_fiscal_descricao || data.cnae_fiscal,
                municipio: data.municipio,
                uf: data.uf,
                socios: (data.qsa || []).map(s => ({
                    nome: s.nome,
                    qualificacao: s.qual
                }))
            };
        } catch (err) {
            return { erro: err.message };
        }
    }

    calcularRisco(registro) {
        let risco = 0;

        if ((registro.total_valor || 0) > 500000) risco += 30;
        else if ((registro.total_valor || 0) > 100000) risco += 15;

        if ((registro.ocorrencias || 0) > 5) risco += 25;
        else if ((registro.ocorrencias || 0) > 2) risco += 10;

        if ((registro.num_vereadores || 0) > 1) risco += 20;

        if (registro.receitaws?.situacao && registro.receitaws.situacao !== 'ATIVA') risco += 25;

        const anosAberta = registro.receitaws?.abertura
            ? (new Date() - new Date(registro.receitaws.abertura.split('/').reverse().join('-'))) / (365.25 * 24 * 3600 * 1000)
            : 10;
        if (anosAberta < 1) risco += 20;

        return {
            score: Math.min(risco, 100),
            nivel: risco >= 80 ? 'ALTO' : risco >= 50 ? 'MÉDIO' : 'BAIXO'
        };
    }

    async analisarArquivo(inputPath, consultarAPI = false) {
        const content = fs.readFileSync(inputPath, 'utf8');
        const cnpjs = this.extrairDe(content);

        console.log(`📋 ${cnpjs.length} CNPJs encontrados em ${inputPath}`);

        const resultados = [];
        for (const { limpo, formatado } of cnpjs) {
            const registro = { cnpj: formatado, cnpj_limpo: limpo };

            if (consultarAPI) {
                registro.receitaws = await this.consultarReceitaWS(limpo);
                await new Promise(r => setTimeout(r, DELAY_MS));
            }

            const risco = this.calcularRisco(registro);
            registro.score_risco = risco.score;
            registro.nivel_risco = risco.nivel;

            resultados.push(registro);
            console.log(`  ✅ ${formatado} — Risco: ${risco.nivel} (${risco.score})`);
        }

        return resultados;
    }
}

// Execução via linha de comando
if (require.main === module) {
    const inputPath = process.argv[2];
    const consultarAPI = process.argv.includes('--api');

    if (!inputPath) {
        console.log('Uso: node extract_cnpj.js <arquivo> [--api]');
        console.log('  --api  Consulta a API ReceitaWS (lento, rate limit 3/min)');
        process.exit(0);
    }

    const extractor = new CNPJExtractor();
    extractor.analisarArquivo(inputPath, consultarAPI).then(resultados => {
        const outputPath = path.join(__dirname, '../output/cnpjs_beneficiarios.json');
        fs.mkdirSync(path.dirname(outputPath), { recursive: true });
        fs.writeFileSync(outputPath, JSON.stringify(resultados, null, 2));
        console.log(`\n💾 Resultados salvos em: ${outputPath}`);
        console.log(`   Total: ${resultados.length} CNPJs | Altos riscos: ${resultados.filter(r => r.nivel_risco === 'ALTO').length}`);
    }).catch(err => {
        console.error('Erro:', err.message);
        process.exit(1);
    });
}

module.exports = { CNPJExtractor };
