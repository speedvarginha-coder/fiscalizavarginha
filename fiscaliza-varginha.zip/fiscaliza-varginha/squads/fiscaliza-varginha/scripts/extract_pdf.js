/**
 * extract_pdf.js
 * Extrai texto e dados estruturados de PDFs do Diário Oficial
 * 
 * Uso: node extract_pdf.js [url_ou_caminho_do_pdf]
 */

const fs = require('fs');
const path = require('path');

// Padrões de extração
const PATTERNS = {
    cnpj:      /\b\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}\b/g,
    cpf:       /\b\d{3}\.\d{3}\.\d{3}-\d{2}\b/g,
    valor:     /R\$\s*([\d\.]+,\d{2})/g,
    contrato:  /contrato\s+n[º°\.]\s*(\d+[\/-]?\d*)/gi,
    licitacao: /pregão|concorrência|tomada de preços|chamamento|inexigibilidade|dispensa/gi,
    nomeacao:  /nomear?|exonerar?|designar?|cargo\s+comissionado/gi,
    decreto:   /decreto\s+n[º°\.]\s*(\d+)/gi,
    data:      /\b(\d{2}\/\d{2}\/\d{4})\b/g
};

async function downloadPDF(url) {
    console.log(`📥 Baixando PDF: ${url}`);
    const response = await fetch(url, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/pdf,*/*'
        }
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}: ${url}`);
    return Buffer.from(await response.arrayBuffer());
}

async function extractFromBuffer(buffer, sourceUrl = '') {
    let pdfParse;
    try {
        pdfParse = require('pdf-parse');
    } catch (e) {
        console.error('❌ Instale pdf-parse: npm install pdf-parse');
        process.exit(1);
    }

    const data = await pdfParse(buffer);
    const text = data.text;

    // Extrai matches de cada padrão
    const extracted = {};
    for (const [key, pattern] of Object.entries(PATTERNS)) {
        const matches = [...text.matchAll(new RegExp(pattern.source, pattern.flags))];
        extracted[key] = [...new Set(matches.map(m => m[0]))];
    }

    // Identifica seções
    const sections = [];
    if (extracted.licitacao.length > 0) sections.push('licitacoes');
    if (extracted.contrato.length > 0) sections.push('contratos');
    if (extracted.nomeacao.length > 0) sections.push('nomeacoes');
    if (extracted.decreto.length > 0) sections.push('decretos');

    return {
        source: sourceUrl,
        paginas: data.numpages,
        caracteres: text.length,
        secoes_encontradas: sections,
        cnpjs: extracted.cnpj,
        valores: extracted.valor,
        contratos: extracted.contrato,
        datas: extracted.data.slice(0, 10),
        texto_resumido: text.substring(0, 2000),
        processado_em: new Date().toISOString()
    };
}

async function processURLs(urls) {
    const results = [];
    for (const url of urls) {
        try {
            const buffer = url.startsWith('http')
                ? await downloadPDF(url)
                : fs.readFileSync(url);
            const result = await extractFromBuffer(buffer, url);
            console.log(`✅ ${url} → ${result.paginas} páginas, ${result.cnpjs.length} CNPJs, ${result.valores.length} valores`);
            results.push(result);
        } catch (err) {
            console.error(`❌ Erro em ${url}: ${err.message}`);
            results.push({ source: url, erro: err.message });
        }
        // Delay entre PDFs
        await new Promise(r => setTimeout(r, 1000));
    }
    return results;
}

// Execução via linha de comando
if (require.main === module) {
    const args = process.argv.slice(2);
    if (!args.length) {
        console.log('Uso: node extract_pdf.js <url_ou_arquivo> [url2] [url3]...');
        process.exit(0);
    }

    processURLs(args).then(results => {
        const outputPath = path.join(__dirname, '../output/pdf_diario_raw.json');
        fs.mkdirSync(path.dirname(outputPath), { recursive: true });
        fs.writeFileSync(outputPath, JSON.stringify(results, null, 2));
        console.log(`\n💾 Resultados salvos em: ${outputPath}`);
    }).catch(err => {
        console.error('Erro fatal:', err.message);
        process.exit(1);
    });
}

module.exports = { extractFromBuffer, processURLs };
