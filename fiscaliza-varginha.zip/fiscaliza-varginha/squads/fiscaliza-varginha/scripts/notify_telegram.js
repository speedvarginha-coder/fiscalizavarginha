/**
 * notify_telegram.js
 * Envia relatórios e alertas do Fiscaliza Varginha para o Telegram
 * 
 * Uso: node notify_telegram.js [analise_redes.json] [analise_recorrencia.json] [relatorio.md] [dashboard_url]
 * 
 * Variáveis de ambiente necessárias:
 *   TELEGRAM_BOT_TOKEN - token do bot criado no @BotFather
 *   TELEGRAM_CHAT_ID   - ID do chat (@username ou número)
 */

require('dotenv').config({ path: '../.env' });
const fs = require('fs');
const path = require('path');

class TelegramNotifier {
    constructor(token, chatId) {
        this.token = token;
        this.chatId = chatId;
        this.apiBase = `https://api.telegram.org/bot${token}`;
    }

    async sendMessage(text, parseMode = 'Markdown', replyMarkup = null) {
        const url = `${this.apiBase}/sendMessage`;
        const body = {
            chat_id: this.chatId,
            text: text.substring(0, 4096),
            parse_mode: parseMode,
            disable_web_page_preview: false
        };
        if (replyMarkup) body.reply_markup = JSON.stringify(replyMarkup);

        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        const result = await response.json();
        if (!result.ok) console.error('Telegram erro:', result.description);
        return result;
    }

    async sendDocument(filePath, caption = '') {
        const { FormData, Blob } = require('node:buffer');
        const fileContent = fs.readFileSync(filePath);
        const formData = new FormData();
        formData.append('chat_id', this.chatId);
        formData.append('document', new Blob([fileContent]), path.basename(filePath));
        if (caption) formData.append('caption', caption);

        const response = await fetch(`${this.apiBase}/sendDocument`, {
            method: 'POST',
            body: formData
        });
        return response.json();
    }

    async enviarResumoSemanal(dados, dashboardUrl) {
        const totalValor = (dados.total_valor || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        const semana = new Date().toLocaleDateString('pt-BR');

        const msg = `
🔍 *ZELA VARGINHA — Relatório Semanal*
📅 ${semana}

📊 *Emendas aprovadas:* ${dados.total_emendas || 0}
💰 *Valor total:* ${totalValor}
🏛️ *Sessões realizadas:* ${dados.total_sessoes || 0}
📄 *Novos contratos:* ${dados.total_contratos || 0}
🚨 *Alertas críticos:* ${dados.alertas?.length || 0}

${dados.dica_geral || 'Acompanhe os gastos da Câmara e cobre transparência dos vereadores!'}

🔗 [Ver Dashboard Completo](${dashboardUrl})
        `.trim();

        return this.sendMessage(msg);
    }

    async enviarAlertasCriticos(conflitos, dashboardUrl) {
        const criticos = (conflitos || []).filter(c => (c.score_risco || 0) > 70);
        console.log(`📢 Enviando ${criticos.length} alerta(s) crítico(s)...`);

        for (const conflito of criticos) {
            const valor = (conflito.valor_emenda || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
            const msg = `
🚨 *ALERTA PRIORITÁRIO*

👤 *Vereador:* ${conflito.vereador || 'N/D'}
⚠️ *Problema:* ${conflito.descricao || 'Verificar manualmente'}
💰 *Valor envolvido:* ${valor}

*Como cobrar:*
📞 ${conflito.telefone || 'Ligue 156 (ouvidoria)'}
📧 ${conflito.email || 'ouvidoria@camaravarginha.mg.gov.br'}
${conflito.url_post ? `💬 [Ver post original](${conflito.url_post})` : ''}

Responda com "COBRAR" para receber um roteiro personalizado de cobrança.
            `.trim();

            const markup = {
                inline_keyboard: [[
                    { text: '📊 Ver no Dashboard', url: dashboardUrl },
                    { text: '✉️ Modelo de Cobrança', callback_data: `cobrar_${(conflito.vereador || 'vereador').replace(/\s/g, '_')}` }
                ]]
            };

            await this.sendMessage(msg, 'Markdown', markup);
            await this.delay(1500);
        }
    }

    async enviarChecklist() {
        const msg = `
✅ *Checklist do Cidadão Fiscal — Semana ${new Date().toLocaleDateString('pt-BR')}*

O que você já fez esta semana?

1️⃣ Conferiu as emendas no dashboard
2️⃣ Cobrou algum vereador (email/telefone/redes)
3️⃣ Compartilhou o relatório no grupo do bairro
4️⃣ Consultou o Diário Oficial
5️⃣ Salvou o número da ouvidoria: *156*

Responda com os números das ações concluídas!
🏙️ *Varginha mais transparente começa com você.*
        `.trim();

        return this.sendMessage(msg);
    }

    async enviarRelatorioArquivo(relatorioPath) {
        if (relatorioPath && fs.existsSync(relatorioPath)) {
            await this.sendDocument(relatorioPath, '📄 Relatório completo da semana em anexo');
            return true;
        }
        return false;
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async run(analiseRedesPath, analiseRecorrenciaPath, relatorioPath, dashboardUrl = 'http://localhost:3000') {
        console.log('📢 Iniciando envio de notificações Telegram...\n');

        let analiseRedes = {};
        let analiseRecorrencia = {};

        try {
            if (fs.existsSync(analiseRedesPath)) {
                analiseRedes = JSON.parse(fs.readFileSync(analiseRedesPath, 'utf8'));
            }
            if (fs.existsSync(analiseRecorrenciaPath)) {
                analiseRecorrencia = JSON.parse(fs.readFileSync(analiseRecorrenciaPath, 'utf8'));
            }
        } catch (e) {
            console.warn('Usando dados mínimos (arquivos de análise não encontrados)');
        }

        const dadosMerge = {
            ...analiseRedes,
            ...analiseRecorrencia,
            alertas: [...(analiseRedes.conflitos || []), ...(analiseRecorrencia.alertas || [])]
        };

        await this.enviarResumoSemanal(dadosMerge, dashboardUrl);
        await this.delay(2000);

        await this.enviarAlertasCriticos(dadosMerge.alertas, dashboardUrl);
        await this.delay(2000);

        if (relatorioPath) {
            const enviou = await this.enviarRelatorioArquivo(relatorioPath);
            if (enviou) await this.delay(2000);
        }

        await this.enviarChecklist();

        console.log('\n✅ Todas as notificações enviadas com sucesso!');
    }
}

// Execução via linha de comando
if (require.main === module) {
    const token = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = process.env.TELEGRAM_CHAT_ID;

    if (!token || !chatId) {
        console.error('❌ Defina TELEGRAM_BOT_TOKEN e TELEGRAM_CHAT_ID no arquivo .env');
        process.exit(1);
    }

    const notifier = new TelegramNotifier(token, chatId);
    const [,, ar = '../output/analise_redes.json', arec = '../output/analise_recorrencia.json',
        rel = '../output/relatorio_semanal.md', url = 'http://localhost:3000'] = process.argv;

    notifier.run(ar, arec, rel, url).catch(err => {
        console.error('Erro:', err.message);
        process.exit(1);
    });
}

module.exports = { TelegramNotifier };
