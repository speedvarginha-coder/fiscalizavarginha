/**
 * scrape_social.js
 * Coleta posts públicos dos vereadores nas redes sociais
 * 
 * ATENÇÃO: Respeitar termos de serviço. Usar apenas perfis públicos.
 * O Playwright reutiliza sessão salva (login manual na primeira vez).
 * 
 * Uso: node scrape_social.js [perfis_vereadores.json]
 */

const fs = require('fs');
const path = require('path');

const DELAY_MIN = 3000;
const DELAY_MAX = 6000;

function delay(min = DELAY_MIN, max = DELAY_MAX) {
    const ms = Math.floor(Math.random() * (max - min)) + min;
    return new Promise(r => setTimeout(r, ms));
}

class SocialScraper {
    constructor(browserContext) {
        this.context = browserContext;
    }

    async scrapeInstagram(username) {
        const handle = username.replace('@', '');
        const page = await this.context.newPage();
        const posts = [];

        try {
            await page.goto(`https://www.instagram.com/${handle}/`, {
                waitUntil: 'networkidle',
                timeout: 30000
            });
            await delay();

            // Aceitar cookies se aparecer
            try {
                await page.click('button:has-text("Allow")', { timeout: 3000 });
            } catch (_) {}
            try {
                await page.click('button:has-text("Aceitar")', { timeout: 3000 });
            } catch (_) {}

            // Scroll para carregar grid
            await page.evaluate(() => window.scrollBy(0, window.innerHeight));
            await delay(2000, 3000);

            // Coletar links dos posts
            const postLinks = await page.$$eval(
                'article a[href*="/p/"]',
                els => els.slice(0, 8).map(el => el.href)
            );

            console.log(`  Instagram @${handle}: ${postLinks.length} posts encontrados`);

            for (const link of postLinks.slice(0, 5)) {
                await page.goto(link, { waitUntil: 'networkidle', timeout: 20000 });
                await delay();

                const legenda = await page.$eval(
                    'div._a9zr, div[class*="Caption"]',
                    el => el.innerText
                ).catch(() => '');

                const data = await page.$eval(
                    'time',
                    el => el.getAttribute('datetime')
                ).catch(() => null);

                posts.push({
                    url: link,
                    legenda: legenda.substring(0, 600),
                    data,
                    plataforma: 'instagram'
                });

                await delay();
            }
        } catch (err) {
            console.warn(`  ⚠️ Instagram @${handle}: ${err.message}`);
            posts.push({ erro: err.message, username: handle, plataforma: 'instagram' });
        } finally {
            await page.close();
        }

        return posts;
    }

    async scrapeTwitter(username) {
        const handle = username.replace('@', '');
        const page = await this.context.newPage();
        const tweets = [];

        try {
            await page.goto(`https://twitter.com/${handle}`, {
                waitUntil: 'networkidle',
                timeout: 30000
            });
            await delay(4000, 6000);

            await page.evaluate(() => window.scrollBy(0, 900));
            await delay(2000, 3000);

            const extracted = await page.$$eval(
                'article[data-testid="tweet"]',
                articles => articles.slice(0, 10).map(a => ({
                    texto: a.querySelector('[data-testid="tweetText"]')?.innerText || '',
                    data: a.querySelector('time')?.getAttribute('datetime') || ''
                }))
            ).catch(() => []);

            tweets.push(...extracted.map(t => ({ ...t, plataforma: 'twitter', handle })));
            console.log(`  Twitter @${handle}: ${tweets.length} tweets`);
        } catch (err) {
            console.warn(`  ⚠️ Twitter @${handle}: ${err.message}`);
            tweets.push({ erro: err.message, username: handle, plataforma: 'twitter' });
        } finally {
            await page.close();
        }

        return tweets;
    }

    async scrapeFacebook(username) {
        const page = await this.context.newPage();
        const posts = [];

        try {
            await page.goto(`https://facebook.com/${username}`, {
                waitUntil: 'networkidle',
                timeout: 30000
            });
            await delay(5000, 7000);

            const extracted = await page.$$eval(
                'div[data-pagelet^="FeedUnit"]',
                divs => divs.slice(0, 5).map(d => ({
                    texto: d.innerText.substring(0, 500)
                }))
            ).catch(() => []);

            posts.push(...extracted.map(p => ({ ...p, plataforma: 'facebook', username })));
            console.log(`  Facebook ${username}: ${posts.length} posts`);
        } catch (err) {
            console.warn(`  ⚠️ Facebook ${username}: ${err.message}`);
            posts.push({ erro: err.message, username, plataforma: 'facebook' });
        } finally {
            await page.close();
        }

        return posts;
    }

    async scrapeAll(perfis) {
        const resultados = {};

        for (const vereador of perfis) {
            console.log(`\n🔍 Scraping: ${vereador.nome}`);
            resultados[vereador.nome] = {
                partido: vereador.partido,
                instagram: [],
                twitter: [],
                facebook: []
            };

            const redes = vereador.redes || {};

            if (redes.instagram) {
                resultados[vereador.nome].instagram = await this.scrapeInstagram(redes.instagram);
                await delay(5000, 8000);
            }
            if (redes.twitter) {
                resultados[vereador.nome].twitter = await this.scrapeTwitter(redes.twitter);
                await delay(5000, 8000);
            }
            if (redes.facebook) {
                resultados[vereador.nome].facebook = await this.scrapeFacebook(redes.facebook);
                await delay(5000, 8000);
            }
        }

        return resultados;
    }
}

// Execução via linha de comando
if (require.main === module) {
    const { chromium } = require('playwright');

    const perfisPath = process.argv[2] || path.join(__dirname, '../_investigations/perfis_vereadores.json');
    const profilePath = path.join(__dirname, '../../../_opensquad/_browser_profile');

    const perfisData = JSON.parse(fs.readFileSync(perfisPath, 'utf8'));
    const perfis = perfisData.vereadores;

    (async () => {
        fs.mkdirSync(profilePath, { recursive: true });

        const browser = await chromium.launchPersistentContext(profilePath, {
            headless: false, // Visível para login manual na primeira execução
            locale: 'pt-BR',
            userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0'
        });

        try {
            const scraper = new SocialScraper(browser);
            const resultados = await scraper.scrapeAll(perfis);

            const outputPath = path.join(__dirname, '../output/redes_sociais_raw.json');
            fs.mkdirSync(path.dirname(outputPath), { recursive: true });
            fs.writeFileSync(outputPath, JSON.stringify(resultados, null, 2));

            console.log(`\n💾 Resultados salvos em: ${outputPath}`);
        } finally {
            await browser.close();
        }
    })().catch(err => {
        console.error('Erro:', err.message);
        process.exit(1);
    });
}

module.exports = { SocialScraper };
