/**
 * test_telegram.js
 * Testa a conexão com o bot do Telegram
 * 
 * Uso: node test_telegram.js
 */

require('dotenv').config({ path: '../.env' });

async function testTelegram() {
    const token = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = process.env.TELEGRAM_CHAT_ID;

    if (!token || !chatId || token.includes('seu_token')) {
        console.error('❌ Configure TELEGRAM_BOT_TOKEN e TELEGRAM_CHAT_ID no arquivo .env');
        console.log('\nComo obter:');
        console.log('1. Abra o Telegram e procure @BotFather');
        console.log('2. Envie /newbot e siga as instruções');
        console.log('3. Guarde o token e coloque no .env');
        console.log('4. Para o CHAT_ID: envie uma mensagem para @userinfobot');
        process.exit(1);
    }

    console.log('🤖 Testando conexão com Telegram...');

    const url = `https://api.telegram.org/bot${token}/sendMessage`;
    const body = {
        chat_id: chatId,
        text: `🔍 *Teste — Zela Varginha*\n\nBot configurado com sucesso! ✅\n\nVocê receberá alertas automáticos da Câmara Municipal de Varginha toda segunda-feira às 9h.\n\n_Squad fiscaliza-varginha pronto para uso._`,
        parse_mode: 'Markdown'
    };

    const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    });

    const result = await response.json();

    if (result.ok) {
        console.log('✅ Mensagem de teste enviada com sucesso!');
        console.log('   Verifique o Telegram para confirmar o recebimento.');
    } else {
        console.error('❌ Erro ao enviar:', result.description);
        console.log('   Verifique se o token e o chat_id estão corretos.');
    }
}

testTelegram().catch(err => {
    console.error('Erro inesperado:', err.message);
    process.exit(1);
});
